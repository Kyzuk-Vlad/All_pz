﻿using System;

namespace Animals_8._2_
{
    public class Animal
    {
        string name;
        string favorite;

        protected Animal (string favorite, string name)
        {
            this.favorite = favorite;
            this.name = name;
        }
        public virtual string ExplainSelf()
        {
            return $"I am {this.name} and my favorite food is {this.favorite}";
        }
    }

    public class Cat : Animal
    {
        public Cat(string favorite, string name) : base(name, favorite)
        {
        }

        public override string ExplainSelf()
        {
            return base.ExplainSelf() + Environment.NewLine +"MEEOW";
        }

    }

    public class Dog : Animal
    {
        public Dog(string favorite, string name) : base(name, favorite)
        {
        }

        public override string ExplainSelf()
        {
            return base.ExplainSelf() + Environment.NewLine + "DJAAF";
        }

    }


    class Program
    {
        static void Main(string[] args)
        {
            Animal cat = new Cat("Pesho", "Whiskas");
            Animal dog = new Dog("Gosho", "Meat");
            Console.WriteLine(cat.ExplainSelf());
            Console.WriteLine(dog.ExplainSelf());
        }
    }
}
