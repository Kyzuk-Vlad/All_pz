﻿using System;

namespace Shapes_8._3_
{
    public abstract class Shapes
    {
        public abstract double CalculatePerimeter();
        public abstract double CalculateArea();
        public virtual string Draw()
        {
        return "Drawing ";
        }
    }

    public class Rectangle : Shapes
    {
        private double height;
        private double width;

        public Rectangle(double height, double width)
        {
            this.height = height;
            this.width = width;

        }

        public double Width 
        {
            get { return width; }
            private set { width = value; }
        }
        public double Height
        {
            get { return height; }
            private set { height = value; }
        }

        public override double CalculatePerimeter()
        {
            return 2 * (Width +  Height);
        }

        public override double CalculateArea()
        {
            return (Width * Height);
        }

        public override string Draw()
        {
            return base.Draw() + Environment.NewLine + "Rectangle";
        }


    }

    public class Circle : Shapes
    {
        private double radius;


        public Circle(double radius)
        {
            this.radius = radius;
        }

        public double Radius
        {
            get { return radius; }
            private set { radius = value; }
        }


        public override double CalculatePerimeter()
        {
            return 2 * Math.PI * Radius;
        }

        public override double CalculateArea()
        {
            return Math.PI * Radius * Radius;
        }

        public override string Draw()
        {
            return base.Draw() + Environment.NewLine + "Circle";
        }


    }



    class Program
    {
        static void Main(string[] args)
        {
            Circle circle = new Circle(8);
            Rectangle rectangle = new Rectangle(3,4);

            Console.WriteLine(rectangle.Draw());
            Console.WriteLine(rectangle.CalculatePerimeter());
            Console.WriteLine(rectangle.CalculateArea());

            Console.WriteLine(circle.Draw());
            Console.WriteLine(circle.CalculatePerimeter());
            Console.WriteLine(circle.CalculateArea());



        }
    }
}
