﻿using System;

namespace Pairs_by_Difference
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter count of numbers: ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int [n];

            Console.WriteLine("Enter your difference: ");
            int dif = int.Parse(Console.ReadLine());
            int count = 0;

            for (int i = 0; i < n; i++)
              {
               Console.WriteLine("Enter {0} element", i + 1);
               a[i] = int.Parse(Console.ReadLine());
              }

            for (int i = 0; i < a.Length; i++)
             {
                for (int j = 0; j < a.Length; j++)
                 {

                    if (dif == a[i] + a[j] || dif == a[i] - a[j] || dif == a[j] - a[i])
                      count++;
                 }
             }
            Console.WriteLine("Count of posible combination: " + count/2);
            Console.ReadKey();
        }
    }
}
