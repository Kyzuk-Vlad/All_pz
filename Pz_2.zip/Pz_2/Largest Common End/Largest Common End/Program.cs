﻿using System;

namespace Largest_Common_End
{
    class Program
    {
        static void Main(string[] args)
        {
            string strLow;
            string strCap;
            string result = "equal to ";
            int x = 0;
            int pos = 1;

            strLow = Console.ReadLine();
            strCap = Console.ReadLine();



            x = String.CompareOrdinal(strLow, pos, strCap, pos, 1);
            if (x < 0) result = "less than";
            if (x > 0) result = "greater than";
            Console.WriteLine("CompareOrdinal(\"{0}\"[{2}], \"{1}\"[{2}]):", strLow, strCap, pos);
            Console.WriteLine("   '{0}' is {1} '{2}'", strLow[pos], result, strCap[pos]);


        }
    }
}
