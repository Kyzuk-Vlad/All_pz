﻿using System;

namespace Equal_Sums
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter count of numbers: ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            int sum1 = 0, sum2 = 0;
            bool fin = false;


            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine("Enter {0} element", i + 1);
                a[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 1; i < a.Length - 1; i++)
             {
                for (int j = 0; j < i; j++)
                 {
                    sum1 = sum1 + a[j];
                 }
                for (int j = i + 1; j < a.Length; j++)
                 {
                    sum2 = sum2 + a[j];
                 }

                if (sum1 == sum2)
                 {
                    Console.WriteLine("Its : " + i);
                    fin = true;
                 }
                sum1 = 0;
                sum2 = 0;
             }
            if (a.Length == 1)
            {
                Console.WriteLine("0");
            }
            else
            if (fin == false)
            {
                Console.WriteLine("no");
            }
            Console.ReadKey();
        }
    }
}
