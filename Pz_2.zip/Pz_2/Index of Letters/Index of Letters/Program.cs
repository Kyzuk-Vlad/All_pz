﻿using System;

namespace Index_of_Letters
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your word: ");
            string s = Console.ReadLine();
            for (int i = 0; i< s.Length; i++)
            {
                Console.WriteLine(s[i] + " -> " + ((int)s[i] - 97));
            }
            Console.ReadKey();
        }
    }
}
