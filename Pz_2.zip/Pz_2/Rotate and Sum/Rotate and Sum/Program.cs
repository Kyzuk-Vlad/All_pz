﻿using System;

namespace Rotate_and_Sum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter size of array: ");
            int a;
            a = Convert.ToInt32(Console.ReadLine());
            int[] b = new int[a];
            int[] c = new int[a];
            int[] sum = new int[a];
            Random rnd = new Random();

            for (int i = 0; i < a; i++)
                b[i] = rnd.Next(11);

            for (int i = 0; i < a; i++)
                Console.Write(b[i] + " ");

            Console.WriteLine("\t");
            Console.WriteLine("Enter count of time's: ");
            int counter = Convert.ToInt32(Console.ReadLine());
            for (int l = 0; l < counter; l++)
            {
                for (int i = 0, j = 1; i < a - 1; i++, j++)
                {
                    if (i == 0)
                    {
                        c[i] = b[b.Length - 1];
                        c[j] = b[i];
                    }
                    else
                        c[j] = b[i];
                }
                for (int i = 0; i < sum.Length; i++)
                {
                    if (counter != 1)
                    {
                        if (l == 1)
                        {
                            sum[i] = b[i] + c[i];
                            Console.Write(sum[i] + " ");
                        }
                        else
                        {
                            sum[i] = sum[i] + c[i];
                            Console.Write(sum[i] + " ");
                        }
                    }
                    else
                    {
                        for (int t = 0; t < a; t++)
                        {
                            Console.Write(c[t] + " ");
                        }
                        break;
                    }
                }
                Console.WriteLine(" ");

                for (int i = 0; i < a; i++)
                    b[i] = c[i];

                for (int i = 0; i < a; i++)
                    c[i] = 0;
            }
            Console.ReadKey();
        }
    }
}
