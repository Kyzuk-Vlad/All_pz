﻿using System;
namespace Max_Sequence_of_Increasing_Elements
{
    class Program
    {
        static void Main(string[] args)
        {
         Console.WriteLine("Enter size of array: ");
         int n = Convert.ToInt32(Console.ReadLine());
         int[] a = new int[n];
         Console.WriteLine("Enter array: ");
         string[] str = Console.ReadLine().Split(new char[] { ' ', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries);
         for (int i = 0; i < (n < str.Length ? n : str.Length); ++i)
             a[i] = Convert.ToInt32(str[i]);

        int len = 0;
        int bestlen = len;
        int start = 0, bestStart = 0;
            for (int i = 1; i < n; i++)
             {
                if (a[i] > a[start]) 
                  len++;
                else
                  {
                    start = i;
                    len = 1;
                  }
                if (bestlen < len)
                  {
                    bestlen = len;
                    bestStart = start;
                  }
             }


            for (int i = bestStart; i < bestlen + bestStart; i++)
                Console.Write($"{a[i]} ");
            
            Console.ReadKey();
        }
    }
}
