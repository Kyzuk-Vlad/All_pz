﻿using System;

namespace Most_Frequent_Number
{
    class Program
    {
        public static int MostFrequent(int[] a, out int cou)
         {

            int MF, NF, i, k;
            Array.Sort(a);
            k = a[0];
            MF = 0; i = 0; cou = 0;
            while (i < a.Length)
              {
                NF = 0;
                while (k == a[i])
                  {
                    NF++;
                    i++;
                    if (i == a.Length)
                      break;
                  }
                if (NF > MF)
                  {
                    MF = NF;
                    cou = k;
                  }

                if (i < a.Length)
                    k = a[i];
              }
            return (MF);
         }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter size of array: ");
            int n = int.Parse(Console.ReadLine());
            int k;
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
              {
                Console.WriteLine("Enter {0} element", i + 1);
                 a[i] = int.Parse(Console.ReadLine());
              }
            int l = MostFrequent(a, out k);
            Console.WriteLine("Number = {0} Count = {1}", k, l);
            Console.ReadKey();
        }
    }
}