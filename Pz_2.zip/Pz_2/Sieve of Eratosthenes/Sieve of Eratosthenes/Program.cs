﻿using System;

namespace Sieve_of_Eratosthenes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your number: ");
            int n;
            n = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[n + 1];

            for (int i = 1; i <= n; i++)
                array[i] = i;

            Console.WriteLine(" ");

            for (int i = 1; i < n + 1; i++)
            {
                if (i != 2)

                    if (array[i] % 2 == 0)
                    {
                        array[i] = 0;
                    }

                if (i > 8)
                {
                    if (array[i] % 3 == 0)
                        array[i] = 0;

                    if (array[i] % 5 == 0)
                        array[i] = 0;

                    if (array[i] % 7 == 0)
                        array[i] = 0;
                }

            }
            Console.WriteLine(" ");

            for (int i = 1; i < n + 1; i++)
            {
                if (array[i] != 0)
                    Console.Write(array[i] + " ");
            }
            Console.ReadKey();
        }
    }
}