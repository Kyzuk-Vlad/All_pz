﻿using System;
using System.Collections.Generic;
namespace Gedi_galaxy_3_
{
    class Galaxi
    {
        public int[,] arr;
        public void Input(int n, int m)
        {
            arr = new int[n, m];
            int value = 0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    arr[i, j] = value;
                    value++;
                }
            }
        }
        public static void Compare(Ivo ivo, Evil evil)
        {

            for (int i = 0; i < ivo.Stars.Count; i++)
            {
                for (int j = 0; j < evil.Stars.Count; j++)
                {
                    if (ivo.Stars[i] == evil.Stars[j])
                    {
                        ivo.Sum -= ivo.Stars[i];
                        break;
                    }
                }
            }
        }
    }


        abstract class Person
        {
            public List<int> Stars = new List<int>();
            public int row { get; set; }
            public int col { get; set; }
            public int Sum { get; set; }
            abstract public void AddElements(Galaxi galaxi);
        }

        class Ivo : Person
        {
            public override void AddElements(Galaxi galaxi)
            {
                int n = row;
                int m = col;
                while (m < galaxi.arr.GetLength(1) && n >= 0)
                {
                    Stars.Add(galaxi.arr[n, m]);
                    Sum += galaxi.arr[n, m];
                    n--;
                    m++;
                }
            }
        }
        class Evil : Person
        {
            public override void AddElements(Galaxi galaxi)
            {
                int n = row;
                int m = col;
                while (n >= 0 && m >= 0)
                {
                    Stars.Add(galaxi.arr[n, m]);
                    Sum += galaxi.arr[n, m];
                    n--;
                    m--;
                }
            }
        }
    

    class Program
    {
        static void Main(string[] args)
        {
        Galaxi array = new Galaxi();
        Ivo ivo = new Ivo();
        Evil evil = new Evil();
        string[] s = Console.ReadLine().Split(' ');
        int n = int.Parse(s[0]);
        int m = int.Parse(s[1]);
        array.Input(n, m);
        for (int i = 0; i < 50; i++)
        {
            string[] s1 = Console.ReadLine().Split(' ');
            if (s1[0] == "Let")
                break;
            else
            {
                ivo.row = int.Parse(s1[0]) - 1;
                ivo.col = int.Parse(s1[1]) + 1;
                ivo.AddElements(array);
                string[] s2 = Console.ReadLine().Split(' ');
                evil.row = int.Parse(s2[0]) - 1;
                evil.col = int.Parse(s2[1]) - 1;
                evil.AddElements(array);

            }
        }
        Galaxi.Compare(ivo, evil);
        Console.WriteLine($"{ivo.Sum}");
        Console.ReadKey();
    }
    }
}