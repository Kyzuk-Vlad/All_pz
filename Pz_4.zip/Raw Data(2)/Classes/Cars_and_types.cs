﻿using System;

namespace Classes
{
    public class Engine
    {
      public int speed;
      public int power;
        public Engine(int a, int b)
        {
            this.speed = a;
            this.power = b;
        }
    }
    public class Cargo
    {
       public int weight;
       public string type;
        public Cargo(int a, string b)
        {
            this.weight = a;
            this.type = b;
        }
    }
    public class Tire
    {
       public int age;
       public double pressure;
         public Tire(int a , double b)
         {
            this.age = a;
            this.pressure = b;  
         }
    }
       abstract public class Car
        {
            public string model {get; set;}
            public Engine engine;
            public Cargo cargo;
            public Tire[] tire = new Tire[4];

        public Car(string model, int speed, int power, int weight, string type,
            double pressure0, int age0,
            double pressure1, int age1,
            double pressure2, int age2,
            double pressure3, int age3)
        {
            this.model = model;
            engine = new Engine(speed, power);
            cargo = new Cargo(weight, type);
            tire[0] = new Tire(age0, pressure0);
            tire[1] = new Tire(age1, pressure1);
            tire[2] = new Tire(age2, pressure2);
            tire[3] = new Tire(age3, pressure3);
        }

        }

    public class Cast : Car
    {
        public string cast { get; set; }
        public Cast (string model, int speed, int power, int weight, string type,
            double pressure0, int age0,
            double pressure1, int age1,
            double pressure2, int age2,
            double pressure3, int age3) : base(model, speed, power, weight, type,
            pressure0, age0,
            pressure1, age1,
            pressure2, age2,
            pressure3, age3)
        {
            this.cast = type;
        }
        static public void fragile(Car[] car, int n)
        {
            for (int i = 0; i < n; i++)
            {
                if (car[i].cargo.type == "fragile")
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if (car[i].tire[j].pressure < 1)
                        {
                            Console.WriteLine($"{car[i].model}");
                            break;
                        }
                    }
                }
            }

        }
        static public void flamable(Car[] car, int n)
        {
            for (int i = 0; i < n; i++)
            {
                if (car[i].cargo.type == "flamable" && car[i].engine.power > 250)
                {
                    Console.WriteLine($"{car[i].model}");
                }
            }

        }
    }
    }
