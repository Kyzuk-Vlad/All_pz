﻿using System;
using Classes;
using Type = Classes.Cast;

namespace Raw_Data_2
{
    class Program
    {
       
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            Car[] car = new Car[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                car[i] = new Cast (s[0], Convert.ToInt32(s[1]), Convert.ToInt32(s[2]), Convert.ToInt32(s[3]), s[4],
                                   Convert.ToDouble(s[5]), Convert.ToInt32(s[6]), Convert.ToDouble(s[7]), Convert.ToInt32(s[8]),
                                      Convert.ToDouble(s[9]), Convert.ToInt32(s[10]), Convert.ToDouble(s[11]), Convert.ToInt32(s[12]));
            }
            string r = Console.ReadLine();
            if (r == "fragile")
            {
                Type.fragile(car, n);
            }
            else
            if (r == "flamable")
            {
                Type.flamable(car, n);
            }
            Console.ReadKey();
        }
    }
}