﻿using System;
using System.Collections.Generic;
public class Class1
{
    public class Engine
    {
        public string model { get; set; }
        public int power { get; set; }
        public double displacement { get; set; }
        public string efficiency { get; set; }
        public Engine(string a, int b, double c, string d) { this.model = a; this.power = b; this.displacement = c; this.efficiency = d; }
        public Engine(string a, double c) { this.model = a; this.power = 0; this.displacement = c; }
        public Engine(int b, double c) { this.model = "n/a"; this.power = b; this.displacement = c; }
        public Engine(string a, int b) { this.model = a; this.power = b; this.displacement = 0; }
        public Engine(string a) { this.model = a; this.power = 0; this.displacement = 0; }
    }
    public class Car
    {
        public string model { get; set; }
        public int engine { get; set; }
        public int weight { get; set; }
        public string color { get; set; }

        public Car(string a, int b, int c, string d) { this.model = a; this.engine = b; this.weight = c; this.color = d; }
        public Car(int b, int c, string d) { this.model = "n/a"; this.engine = b; this.weight = c; this.color = d; }
        public Car(string a, int c, string d) { this.model = a; this.engine = 0; this.weight = c; this.color = d; }
        public Car(string a, int b, int c) { this.model = a; this.engine = b; this.weight = c; this.color = "n/a"; }
        public Car(int c, string d) { this.model = "n/a"; this.engine = 0; this.weight = c; this.color = d; }
        public Car(int b, int c) { this.model = "n/a"; this.engine = b; this.weight = c; this.color = "n/a"; }
        public Car(string a, string d) { this.model = a; this.engine = 0; this.weight = 0; this.color = d; }
        public Car(string a, int c) { this.model = a; this.engine = 0; this.weight = c; this.color = "n/a"; }
        public Car(int b) { this.model = "n/a"; this.engine = b; this.weight = 0; this.color = "n/a"; }
        public Car(string a) { this.model = a; this.engine = 0; this.weight = 0; this.color = "n/a"; }
    }
    abstract class Complection
    {
        public List<Car> cars = new List<Car>();
        public List<Engine> engines = new List<Engine>();
        public abstract void print();
    }
    class Final : Complection
    {
        public override void print()
        {
            for (int i = 0; i < cars.Count; i++)
            {
                for (int j = 0; j < engines.Count; j++)
                {
                    if (engines[j].model.Equals(cars[i].engine))
                    {
                        Console.WriteLine($"{cars[i].model}");
                        Console.WriteLine($"  {cars[i].engine}:");
                        Console.WriteLine($"    Power: {engines[j].power}");
                        if (engines[j].displacement == 0)
                            Console.WriteLine($"    Displacement: n/a");
                        else
                            Console.WriteLine($"    Displacement: {engines[j].displacement}");
                        Console.WriteLine($"    Efficiency: {engines[j].efficiency}");
                        if (cars[i].weight == 0)
                            Console.WriteLine($"  Weight: n/a");
                        else
                            Console.WriteLine($"  Weight: {cars[i].weight}");
                        Console.WriteLine($"  Color: {cars[i].color}");
                    }
                }
            }
        }
    }

}
