﻿using System;
using System.Collections.Generic;
namespace Greedy_times
{
    class Bag
    {
        public int Space { get; set; }
        public int amount { get; set; }
        public Bag()
        {
            amount = 0;
        }
        public void AddSpace(int value)
        {
            Space = value;
        }
        public bool checkLimit(int value)
        {
            if (amount + value > Space)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }



    abstract class Treasure
    {
        public List<string> Type { get; set; } = new List<string>();
        public List<int> Amount { get; set; } = new List<int>();
        public int Count { get; set; }
        public Treasure()
        {
            Count = 0;
        }
        public void Add(string type, int value)
        {
            Type.Add(type);
            Amount.Add(value);
            Count += value;
        }

    }

    class Cash : Treasure
    {
        public void Output()
        {
            Console.WriteLine($"<Cash> ${Count}");
            for (int i = 0; i < Type.Count; i++)
            {
                for (int j = 0; j < Type.Count; j++)
                {
                    if (string.Compare(Type[i], Type[j]) > 0)
                    {
                        string tmp = Type[i];
                        Type[i] = Type[j];
                        Type[j] = tmp;
                        int tmp2 = Amount[i];
                        Amount[i] = Amount[j];
                        Amount[j] = tmp2;
                    }
                }
            }
            for (int i = 0; i < Type.Count; i++)
            {
                Console.WriteLine($"##{Type[i]} - {Amount[i]}");
            }
        }
    }

    class Gem : Treasure
    {
        public void Output()
        {
            Console.WriteLine($"<Gem> ${Count}");
            for (int i = 0; i < Type.Count; i++)
            {
                for (int j = 0; j < Type.Count; j++)
                {
                    if (string.Compare(Type[i], Type[j]) > 0)
                    {
                        string tmp = Type[i];
                        Type[i] = Type[j];
                        Type[j] = tmp;
                        int tmp2 = Amount[i];
                        Amount[i] = Amount[j];
                        Amount[j] = tmp2;
                    }
                }
            }
            for (int i = 0; i < Type.Count; i++)
            {
                Console.WriteLine($"##{Type[i]} - {Amount[i]}");
            }
        }
    }

    class Gold : Treasure
    {
        public void Output()
        {
            Console.WriteLine($"<Gold> ${Count}");
            Console.WriteLine($"##Gold - {Count}");
        }
    }






    class Program
    {
        static void Main(string[] args)
        {
            Gem gem = new Gem();
            Gold gold = new Gold();
            Cash cash = new Cash();
            Bag bag = new Bag();
            string[] s = Console.ReadLine().Split(' ');
            bag.AddSpace(int.Parse(s[0]));
            string[] s1 = Console.ReadLine().Split(' ');
            for (int i = 0; i < s1.Length; i += 2)
            {
                if (s1[i] == "Gold")
                {
                    if (bag.checkLimit(int.Parse(s1[i + 1])) == true)
                    {
                        bag.amount += int.Parse(s1[i + 1]);
                        gold.Add(s1[i], int.Parse(s1[i + 1]));
                    }
                }
                else if (s1[i].Length == 3)
                {
                    if (bag.checkLimit(int.Parse(s1[i + 1])) == true && cash.Count + int.Parse(s1[i + 1]) <= gem.Count)
                    {
                        bag.amount += int.Parse(s1[i + 1]);
                        cash.Add(s1[i], int.Parse(s1[i + 1]));
                    }
                }
                else
                {
                    if (bag.checkLimit(int.Parse(s1[i + 1])) == true && gem.Count + int.Parse(s1[i + 1]) <= gold.Count)
                    {
                        bag.amount += int.Parse(s1[i + 1]);
                        gem.Add(s1[i], int.Parse(s1[i + 1]));
                    }
                }
            }
            if (gold.Count > 0)
            {
                gold.Output();
            }
            if (gem.Type.Count != 0)
            {
                gem.Output();
            }
            if (cash.Type.Count != 0)
            {
                cash.Output();
            }
            Console.ReadKey();
        }
    }
}
