﻿using System;


namespace Opinion_Poll
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter count of people: ");
            int n = Convert.ToInt32(Console.ReadLine());
            Person[] a = new Person[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                a[i] = new Person();
                a[i].Name = s[0];
                a[i].Age = Convert.ToInt32(s[1]);
            }

            for (int i = 0; i < n; i++)
            {
               for (int j = i + 1; j < n; j++)
               {
                 int m = 0;
              
                    while (a[i].Name[m] == a[j].Name[m] && m < a[i].Name.Length - 1 && m < a[i].Name.Length - 1)
                    m++;
                    
                    if (a[i].Name[m] < a[j].Name[m])
                    {
                        Person tmp = new Person();
                        tmp = a[j];
                        a[j] = a[i];
                        a[i] = tmp;
                    }
               }
            }
            for (int i = 0; i < n; i++)
            {
                if (a[i].Age > 30)
                {
                    Console.WriteLine($"{a[i].Name} - {a[i].Age}");
                }
            }
            Console.ReadKey();
        }
    }
    }

