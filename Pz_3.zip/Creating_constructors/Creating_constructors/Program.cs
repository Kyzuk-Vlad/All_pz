﻿using System;

namespace Creating_constructors
{
    class Person
    {
        private int age = 18;
        private string name;
        public Person() { name = "No name"; age = 1; }
        public Person(int a) { name = "No name"; age = a; }
        public Person(string n, int a) { name = n; age = a; }
        public void GetInfo()
        {
            Console.WriteLine($"Name: {name}  Age: {age}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person invisible = new Person();
            Person gog = new Person(18);
            Person somebody = new Person("Kersh", 35);

            invisible.GetInfo();
            gog.GetInfo();
            somebody.GetInfo();
        }
    }
}
