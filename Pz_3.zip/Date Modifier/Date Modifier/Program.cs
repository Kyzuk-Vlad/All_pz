﻿using System;

namespace Date_Modifier
{
    class Program
    {
        class DateModifier
        {
            static public void Difference(string a, string b)
            {
                DateTime f = DateTime.Parse(a);
                DateTime s = DateTime.Parse(b);
                int result = DateTime.Compare(f, s);
                 if (result < 0) 
                  Console.WriteLine(s.Subtract(f).Days);
                 
                 else 
                  Console.WriteLine(f.Subtract(s).Days); 
            }
        }

        static void Main(string[] args)
        {
            string a = Console.ReadLine();
            string b = Console.ReadLine();
            DateModifier.Difference(a, b);
            Console.ReadKey();
        }
    }
}
