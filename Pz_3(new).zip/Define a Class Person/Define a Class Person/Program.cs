﻿using Microsoft.Win32.SafeHandles;
using System;

namespace Define_a_Class_Person
{
    class Person
    {
        private int age=18;
        private string name;   
        public Person(string n, int a) { name = n; age = a; }
        public void GetInfo()
        {
            Console.WriteLine($"Name: {name}  Age: {age}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person pecho= new Person("Pecho", 20);
            Person gosho = new Person("Gosho", 18);
            Person stamat = new Person("Stamat", 435);

            pecho.GetInfo();
            gosho.GetInfo();
            stamat.GetInfo();
        }
    }
}
