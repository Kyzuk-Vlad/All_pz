﻿using System;

namespace Speed_Racing
{
    class Program
    {
        private class Car
        {
            string model;
            double consumption;
            double amount;
            int distance;
            public Car(string model, double fuelAm, double fuelCon)
            {
                this.model = model;
                this.amount = fuelAm;
                this.consumption = fuelCon;
                this.distance = 0;
            }
            static public void Check(string Model, int Distance, Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    if (car[i].model == Model)
                    {
                        if (car[i].amount / car[i].consumption > Distance)
                        {
                            car[i].distance += Distance;
                            car[i].amount -= car[i].consumption * Distance;
                        }
                        else
                        {
                            Console.WriteLine("Insufficient fuel for the drive");
                        }
                    }
                }
            }
            static public void Output(Car[] car, int n)
            {
                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine($"{car[i].model} {car[i].amount:0.00} {car[i].distance}");
                }
            }
        }
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            string[] a;
            Car[] car = new Car[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                car[i] = new Car(s[0], Convert.ToDouble(s[1]), Convert.ToDouble(s[2]));
            }
            for (int k = 0; k < 100; k++)
            {
                a = Console.ReadLine().Split(' ');
                if (a[0] == "Drive")
                {
                    Car.Check(a[1], Convert.ToInt32(a[2]), car, n);
                }
                if (a[0] == "End")
                {
                    Car.Output(car, n);
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
