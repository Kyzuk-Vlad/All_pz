﻿using System;

namespace Oldest_family_member
{
    class Person
    {
        string name;
        int age;
        public string Name { get; set; }
        public int Age { get; set; }
    }
    class Family
    {
        Person[] a;
        private int size = 0;
        public Family(int n)
        {
            a = new Person[n];
        }
        public void Add_Member(Person member)
        {
            a[size] = member;
            size++;
        }
        public Person GetOldest()
        {
            int max = 0;
            int max_i = 0;
            for (int i = 0; i < size; i++)
            {
                if (max < a[i].Age)
                {
                    max = a[i].Age;
                    max_i = i;
                }
            }
            return a[max_i];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter count member's of family: ");
            int n = Convert.ToInt32(Console.ReadLine());
            Family family = new Family(n);
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                Person tmp = new Person();
                tmp.Name = s[0];
                tmp.Age = Convert.ToInt32(s[1]);
                family.Add_Member(tmp);
            }
            Console.WriteLine("\n");
            Console.WriteLine("The oldest is: ");
            Console.WriteLine($"{family.GetOldest().Name} {family.GetOldest().Age}");
            Console.ReadKey();
        }
    }
}
