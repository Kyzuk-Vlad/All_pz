﻿using System;
using System.Collections.Generic;
namespace Cara_Salesman2
{
    class Program
    {
        static void Main(string[] args)
        {
            var engines = new List<Class1.Engine>();
            var cars = new List<Class1.Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; ++i)
            {

            }

            Console.ReadKey();
        }
    }
}