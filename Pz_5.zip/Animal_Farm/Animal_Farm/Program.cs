﻿using System;

namespace Animal_Farm
{

    public class Chicken
    {
        private string name;
        private int age;

        public Chicken(string name, int age)
        {
            this.name = name;
            this.age = age;
        }
        private double Age
        {
            get
            {
                return this.age;
            }
            set
            {
                if (value < 0 || value > 15)
                {
                    throw new ArgumentException("Age should be between 0 and 15.");
                }
                this.age = (int)value;
            }
        }

        private string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                if (String.IsNullOrEmpty(value) || String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                this.name = value;
            }
        }


        public double ProductPerDay
        {
            get
            {
                return this.CalculateProductPerDay();
            }
        }

        private double CalculateProductPerDay()
        {
            if (this.Age > 0 && this.Age < 3 || this.Age > 12 && this.Age < 16)
            {
                return 0.5;
            }

            else
            {
                return 1.0;
            }

        }

        class Program
        {
            static void Main(string[] args)
            {
                string n = Console.ReadLine();
                int a = int.Parse(Console.ReadLine());
                try
                {
                    Chicken chicken = new Chicken(n, a);
                    Console.WriteLine("Chicken {0} (age {1}) can produce {2} eggs per day.", chicken.Name, chicken.Age, chicken.ProductPerDay);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                }
                Console.ReadKey();
            }
        }
    }
}
