﻿using System;

namespace Class_Box_Data_Validation
{
    public class Cuboid
    {
        private double length;
        private double width;
        private double height;
        public Cuboid(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }
        private double Length
        {
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                this.length = value;
            }
        }

        private double Width
        {
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                this.width = value;
            }
        }

        private double Height
        {
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                this.height = value;
            }
        }


        public string CalculateVolume()
        {
            double volume = length * width * height;
            return $"{volume}";
        }

        public string CalculateLateralSurfaceArea()
        {
            double lateralSurfaceArea = 2 * length * height + 2 * width * height;
            return $"{lateralSurfaceArea}";
        }

        public string CalculateSurfaceArea()
        {
            double surfaceArea = 2 * length * width + 2 * length * height + 2 * width * height;
            return $"{surfaceArea}";
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            double length = double.Parse(Console.ReadLine());
            double width = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());
            Cuboid cuboid = new Cuboid(length, width, height);
            try { 
            Console.WriteLine($"Surface Area - " + cuboid.CalculateSurfaceArea());
            Console.WriteLine($"Lateral Surface Area - " + cuboid.CalculateLateralSurfaceArea());
            Console.WriteLine($"Volume - " + cuboid.CalculateVolume());
             }
                    catch (ArgumentException exept)
            {
                Console.WriteLine(exept.Message);
            }
        }
    }
}
