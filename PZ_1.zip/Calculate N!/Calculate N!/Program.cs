﻿using System;

namespace Calculate_N_
{

    class Program
    {
        static int fact(int n)
        {
            if ((n == 0) || (n == 1))
                return 1;
            else
                return n * fact(n - 1);
        }




        static void Main(string[] args)
        {

            Console.Write("Enter your number: ");
            int a = Convert.ToInt32(Console.ReadLine());
            int c = fact(a);
            Console.WriteLine("Fact of "+ a + " is " + c);
            Console.ReadKey();

        }
    }
}
