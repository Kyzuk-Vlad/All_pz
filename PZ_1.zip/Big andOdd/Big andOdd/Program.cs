﻿using System;

namespace Big_andOdd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your number: ");
            int a = Convert.ToInt32(Console.ReadLine());            
            if ( a>20 && a%2 != 0)
            {
                Console.Write("True");
            }
            else
                Console.Write("False");
            Console.ReadKey();
        }
    }
}
