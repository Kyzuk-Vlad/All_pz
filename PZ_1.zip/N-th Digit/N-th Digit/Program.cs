﻿using System;

namespace N_th_Digit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your number: ");
            int a= Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter place of your number: ");
            int c= Convert.ToInt32(Console.ReadLine());

            int Nmod = (a / (Convert.ToInt32(Math.Pow(10, c - 1)))) % 10;
            Console.WriteLine(Nmod);

            Console.ReadKey();
        }
    }
}
