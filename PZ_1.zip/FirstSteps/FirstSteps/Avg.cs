﻿using System;

namespace FirstSteps
{
    class Avg
    {
        static void Main(string[] args)
        {

            Console.Write("Enter first number: ");
        
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter ssecond number: ");
  
            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter third number: ");
        
            float c = Convert.ToInt32(Console.ReadLine());
            float avg = (a + b + c)/3;
            Console.WriteLine(avg);


            Console.ReadKey();
        }
    }
}
