﻿using System;

namespace Trapezoid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter first side: ");

            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter second side: ");

            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter hight: ");

            double h = Convert.ToDouble(Console.ReadLine());
            double Square = ((a + b) / 2) * h;
            Console.WriteLine(Square);

            Console.ReadKey();
        }      
    }
}
