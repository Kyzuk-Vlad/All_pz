﻿using System;

namespace Pure_Divisor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your number: ");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a % 13 == 0 || a % 9 == 0 || a % 11 == 0)
            {
                Console.Write("True");
            }
            else
                Console.Write("False");
            Console.ReadKey();
        }
    }
}
