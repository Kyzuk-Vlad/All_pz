﻿using System;

namespace Last_Digit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your number: ");

            int a = Convert.ToInt32(Console.ReadLine());

            
            int Nmod = (a) % 10;
            Console.WriteLine(Nmod);

            Console.ReadKey();
        }
    }
}
