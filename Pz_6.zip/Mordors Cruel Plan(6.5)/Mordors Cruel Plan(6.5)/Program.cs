﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mordor_s_Cruel_Plan_6._5_
{

    public static class FoodPlant
    {
        public static Food TypeOf(string food)
        {
            switch (food)
            {
                case "Cram": return new Cram();
                case "Apple": return new Apple();
                case "Lembas": return new Lembas();
                case "melon": return new Melon();
                case "honeyCake": return new HoneyCake();
                case "Mushrooms": return new Apple();
                default: return new Else();
            }
        }

    }

    public static class MoodFactory
    {
        public static Mood GenMood(int happiness)
        {
            if (happiness < -5)
            {
                return new Mood("Angry");
            }
            else
            if (happiness <= 0)
            {
                return new Mood("Sad");
            }
            else
            if (happiness <= 15)
            {
                return new Mood("Happy");
            }
            else
            {
                return new Mood("JavaScript");
            }
        }
    }

    public abstract class Food
    {
        public int Happiness { get; protected set; }
    }

    public class Cram : Food
    {
        public Cram()
        {
            this.Happiness = 2;
        }
    }

    public class Lembas : Food
    {
        public Lembas()
        {
            this.Happiness = 3;
        }
    }

    public class Apple : Food
    {
        public Apple()
        {
            this.Happiness = 1;
        }
    }

    public class Melon : Food
    {
        public Melon()
        {
            this.Happiness = 1;
        }
    }
    public class HoneyCake : Food
    {
        public HoneyCake()
        {
            this.Happiness = 5;
        }
    }
    public class Mushrooms : Food
    {
        public Mushrooms()
        {
            this.Happiness = -10;
        }
    }

    public class Else : Food
    {
        public Else()
        {
            this.Happiness = -1;
        }
    }

    public class Mood
    {
        public Mood(string moode)
        {
            this.Mooded = moode;
        }

        public string Mooded { get; protected set; }
    }

    public class Gandalf
    {
        private List<Food> food;
        private Mood mood;

        public Gandalf()
        {
            this.food = new List<Food>();
        }

        private void CalculateMood()
        {
            this.mood = MoodFactory.GenMood(this.food.Sum(f => f.Happiness));
        }

        public void TakeFood(string[] food)
        {
            foreach (var f in food)
            {
                Food current = FoodPlant.TypeOf(f);
                this.food.Add(current);
            }

            this.CalculateMood();
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendLine($"{this.food.Sum(f => f.Happiness)}")
                .Append(this.mood.Mooded);

            return builder.ToString();
        }


    }



    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();

            Gandalf gandalf = new Gandalf();
            gandalf.TakeFood(input);
            Console.WriteLine(gandalf);
        }
    }
}