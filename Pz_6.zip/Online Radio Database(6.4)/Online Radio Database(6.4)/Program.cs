﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Online_Radio_Database_6._4_
{

    public class InvalidSongException : Exception
    {
        public InvalidSongException(string message = "Invalid song.")
            : base(message)
        { }
    }

    public class InvalidArtistNameException : InvalidSongException
    {
        public InvalidArtistNameException(string message = "Artist name should be between 3 and 20 symbols.")
           : base(message)
        { }

    }

    public class InvalidSongNameException : InvalidSongException
    {
        public InvalidSongNameException(string message = "Song name should be between 3 and 30 symbols.")
           : base(message)
        { }

    }

    public class InvalidSongLengthException : InvalidSongException
    {
        public InvalidSongLengthException(string message = "Invalid song length.")
           : base(message)
        { }

    }

    public class InvalidSongMinutesException : InvalidSongLengthException
    {
        public InvalidSongMinutesException(string message = "Invalid song length.")
           : base(message)
        { }

    }
    public class InvalidSongSecondsException : InvalidSongLengthException
    {
        public InvalidSongSecondsException(string message = "Invalid song length.")
           : base(message)
        { }

    }

    public class Song 
    {
        private string artist_name;
        private string song_name;
        private int minutes;
        private int secounds;

        public Song(string artist_name, string song_name, int minutes, int secounds)
        {
            this.Artist = artist_name;
            this.Songn = song_name;
            this.Minutes = minutes;
            this.Secounds = secounds;
        }

        public string Artist
        {
            get
            {
                return this.artist_name;
            }

            protected set
            {
                if (value.Length < 3 || value.Length > 20)
                {
                    throw new InvalidArtistNameException();
                } 
                this.artist_name = value;
            }
        }

        public string Songn
        {
            get
            {
                return this.song_name;
            }

            protected set
            {
                if (value.Length < 3 || value.Length > 30)
                {
                    throw new InvalidArtistNameException();
                }
                this.song_name = value;
            }
        }

        public int Minutes
        {
            get
            {
                return this.minutes;
            }

            protected set
            {
                if (value < 0 || value > 14)
                {
                    throw new InvalidArtistNameException();
                }
                this.minutes = value;
            }
        }

        public int Secounds
        {
            get
            {
                return this.secounds;
            }

            protected set
            {
                if (value < 0 || value > 59)
                {
                    throw new InvalidArtistNameException();
                }
                this.secounds = value;
            }
        }
        public TimeSpan Length => new TimeSpan(0, minutes, secounds);

        public int GetLengthInSeconds()
        {
            return this.minutes * 60 + this.secounds;
        }

    }






    public class Playlist
    {
        private List<Song> songs = new List<Song>();
        public int NumberOfSongs => songs.Count;

        public TimeSpan Length
            => songs.Aggregate(TimeSpan.Zero, (total, next) => total + next.Length);
        public string AddSong(Song song)
        {
            songs.Add(song);

            return "Song added.";
        }

        public override string ToString()
        {
            int totalLength = songs.Select(s => s.GetLengthInSeconds()).Sum();
            var builder = new StringBuilder();

            builder.AppendLine($"Songs added: {songs.Count}")
                .Append($"Playlist length: {totalLength / 3600}h {totalLength / 60 % 60}m {totalLength % 60}s");

            return builder.ToString();
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Playlist playlist = new Playlist();


            for (int i = 0; i<n; i++)
            {
                try
                {
                    var songInputs = Console.ReadLine().Split(';');

                    string artist = songInputs[0];
                    string name = songInputs[1];
                    var length = songInputs[2].Split(':');
                    int minutes = int.Parse(length[0]);
                    int seconds = int.Parse(length[1]);

                    var song = new Song(artist, name, minutes, seconds);
                    playlist.AddSong(song);
                    Console.WriteLine("Song added.");
                }
                catch (InvalidSongException ex)
                {
                    Console.WriteLine(ex.Message);
                }


                Console.WriteLine($"Songs added: {playlist.NumberOfSongs}");
                Console.WriteLine($"Playlist length: {playlist.Length:h'h 'm'm 's's'}");
            }
        }
    }
}
