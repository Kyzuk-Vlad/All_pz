﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mankind_6._3_
{
    public class Human
    {
        public string first;
        public string last;
        public Human(string first, string last)
        {
            this.First = first;
            this.Last = last;
        }

        public string First
        {
            get
            {
                return this.first;
            }

            protected set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Expected length at least 4 symbols! Argument: firstName");
                }

                if (!Char.IsUpper(value[0]))
                {
                    throw new ArgumentException("Expected upper case letter! Argument: firstName");
                }

                this.first = value;
            }
        }

        public string Last
        {
            get
            {
                return this.last;
            }

            protected set
            {
                if (value.Length < 2)
                {
                    throw new ArgumentException("Expected length at least 4 symbols! Argument: lastName");
                }

                if (!Char.IsUpper(value[0]))
                {
                    throw new ArgumentException("Expected upper case letter! Argument: lastName");
                }
                this.last = value;
            }
        }


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendLine($"First Name: {First}")
                .AppendLine($"Last Name: {Last}");

            return builder.ToString();
        }
    }


    public class Student : Human
    {
        private string faculty_number;
        public Student(string first, string last, string faculty_number) : base(first, last)
        {
            this.Faculty = faculty_number;
        }

        public string Faculty
        {
            get
            {
                return this.faculty_number;
            }

            protected set
            {
                if (value.Length < 5 || value.Length > 10)
                {
                    throw new ArgumentException("Invalid faculty number!");
                }

                this.faculty_number = value;
            }
        }


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append(base.ToString())
                .AppendLine($"First Name: {First}")
                .AppendLine($"Last Name: {Last}")
                .AppendLine($"Faculty number: {Faculty}");
            return builder.ToString();
        }
    }
        public class Worker : Human
    {
        private decimal week_salary;
        private decimal hours_per_day;
        public Worker(string first, string last, decimal week_salary, decimal hours_per_day) :base (first, last)
        {
            this.Week = week_salary;
            this.Hours = hours_per_day;
        }

        public decimal Week
        {
            get
            {
                return this.week_salary;
            }

            protected set
            {
                if (value < 10)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: weekSalary");
                }
                this.week_salary = value;
            }
        }

        public decimal Hours
        {
            get
            {
                return this.hours_per_day;
            }

            protected set
            {
                if (value < 1 || value > 12)
                {
                    throw new ArgumentException("Expected value mismatch! Argument: workHoursPerDay");
                }

                this.hours_per_day = value;
            }
        }


        private decimal Calculate_Salary()
        {
            return this.Week / (this.Hours * 5);
        }


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append(base.ToString())
                .AppendLine($"Week Salary: {Week:0.00}")
                .AppendLine($"Hours per day: {Hours:0.00}")
                .AppendLine($"Salary per hour: {Calculate_Salary():0.00}");

            return builder.ToString();
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var stud = Console.ReadLine().Split();
                var work = Console.ReadLine().Split();

                string first_name = stud[0];
                string last_name = stud[1];
                string faculty_ = stud[2];

                string first = work[0];
                string last = work[1];
                decimal salary = decimal.Parse(work[2].Replace('.', ','));
                int hours = int.Parse(work[3]);
                Student student = new Student(first_name, last_name, faculty_);
                Worker worker = new Worker(first, last, salary, hours);
                Console.WriteLine(student);
                Console.WriteLine(worker);
            }
            catch (ArgumentException ae)
            {
                Console.WriteLine(ae.Message);
            }
        }
    }




}
